from pathlib import Path
import ast, collections, datetime, itertools, json, os, re, subprocess, sys, textwrap, time, types
R = Path(__file__).resolve().parents[1]
OUT = R / 'results/caller'
PY = sys.executable

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

class Log:

    def __init__(self):
        self.rows = []

    def __getattr__(self, key):
        return lambda *a, **kw: self.rows.append({'kind': key, 'args': [str(x) for x in a]})

class Progress:

    def set_description(self, *a):
        pass
COUNTERS = ['test_passed_on_buggy_but_failed_on_fixed', 'test_passed_on_fixed_but_failed_on_buggy', 'test_passed_on_both', 'test_failed_on_both']

def typed(f, b):
    if f not in ['PASS', 'FAIL'] or b not in ['PASS', 'FAIL']:
        return 'incomplete'
    return {('PASS', 'PASS'): 'both_pass', ('PASS', 'FAIL'): 'effective', ('FAIL', 'PASS'): 'misguided', ('FAIL', 'FAIL'): 'both_fail'}[f, b]
FIXTURE = "import json,sys\nfrom pathlib import Path\nj=json.loads(Path(sys.argv[1]).read_text());mode=j['mode']\nif mode=='PASS':print('Failing tests: 0')\nelif mode=='FAIL':print('Failing tests: 1\\n  - FixtureGenerated::test_one')\nelif mode=='PROCESS_ERROR':print('CONTROLLED_RUNNER_FAILURE');sys.exit(23)\nelif mode=='NO_RESULTS':print('CONTROLLED_ZERO_TESTS_NO_RESULT_HEADER')\nelse:raise ValueError(mode)\n"

def main():
    assert not (OUT / 'summary.json').exists(), 'Do not repeat unchanged run'
    OUT.mkdir(parents=True, exist_ok=True)
    path = R / 'source/retry_branch.py'
    lines = path.read_text().splitlines(keepends=True)
    branch = ''.join(lines)
    ast.parse(branch)
    (OUT / 'exact_retry_branch.py').write_text(branch)
    shim = OUT / 'controlled_runner.py'
    shim.write_text(FIXTURE)
    rows = []
    started = utc()
    t = time.monotonic()
    for fixed, buggy in itertools.product(['PASS', 'FAIL', 'PROCESS_ERROR', 'NO_RESULTS'], ['PASS', 'FAIL', 'PROCESS_ERROR', 'NO_RESULTS', 'COMPILE_SKIP']):
        case = OUT / (fixed + '__' + buggy)
        case.mkdir()
        dirs = {}
        modes = {}
        for side, mode in [('fixed', fixed), ('buggy', buggy)]:
            wd = case / side
            wd.mkdir()
            (wd / 'mode.json').write_text(json.dumps({'mode': mode}))
            dirs[side] = str(wd)
            modes[str(wd)] = mode
        logger = Log()
        calls = []

        def run(argv, **kwargs):
            assert argv[:3] == ['defects4j', 'test', '-w'] and len(argv) == 4 and (argv[3] in modes)
            assert kwargs == {'stdout': subprocess.PIPE, 'stderr': subprocess.STDOUT, 'text': True, 'check': True}
            actual = [PY, '-I', '-S', '-B', str(shim), str(Path(argv[3]) / 'mode.json')]
            begin = utc()
            result = subprocess.run(actual, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=False, timeout=15)
            calls.append({'original_argv': argv, 'actual_argv': actual, 'begin_utc': begin, 'end_utc': utc(), 'returncode': result.returncode, 'stdout': result.stdout, 'timeout_seconds': 15})
            if result.returncode:
                raise subprocess.CalledProcessError(result.returncode, argv, output=result.stdout)
            return subprocess.CompletedProcess(argv, result.returncode, result.stdout)
        env = {'new_res': {'passed_uts_num': 1, 'buggy_compiled': buggy != 'COMPILE_SKIP'}, 'defect_with_compilable_test': set(), 'project_name': 'ControlledFixture', 'bug_id': '1', 'project_dir': dirs['fixed'], 'buggy_project_dir': dirs['buggy'], 'pbar': Progress(), 'method_id': 'controlled_method', 'hashed_package_name': 'FixtureGenerated', 'method_signature': 'controlled_method()', 'class_name_in_code': 'FixtureGenerated', 'num_tests': 1, 're': re, 'subprocess': types.SimpleNamespace(run=run, PIPE=subprocess.PIPE, STDOUT=subprocess.STDOUT, CalledProcessError=subprocess.CalledProcessError), 'logger': logger, 'separator_logger': logger, 'os': os, 'item': {}, 'test_run_log_file_path': str(case / 'fixed.log'), 'buggy_test_run_log_file_path': str(case / 'buggy.log'), 'dst_java_file_path': str(case / 'absent_fixed.java'), 'buggy_dst_java_file_path': str(case / 'absent_buggy.java'), 'dst_test_package_dir': str(case / 'absent_fixed_pkg'), 'buggy_dst_test_package_dir': str(case / 'absent_buggy_pkg'), 'buggy_test_src_dir': str(case), 'test_src_dir': str(case), 'method_name': 'controlled_method'}
        for key in COUNTERS + ['test_failed', 'compiled_but_run_failed_number', 'bug_detected_number', 'fixed_failed_but_buggy_pass_number', 'buggy_non_compiled_number']:
            env[key] = 0
        for key in ['partially_passed', 'compiled_but_run_failed', 'bug_detected', 'fixed_failed_but_buggy_pass', 'buggy_non_compiled']:
            env[key] = []
        for key in ['defects_detected', 'focal_method_invoked_defects']:
            env[key] = set()
        exec(compile(branch, str(OUT / 'exact_retry_branch.py'), 'exec'), env)
        observed = {x: mode if mode in ['PASS', 'FAIL'] else 'MISSING' for x, mode in [('fixed', fixed), ('buggy', buggy)]}
        counts = dict(zip(['misguided', 'effective', 'both_pass', 'both_fail'], [env[x] for x in COUNTERS]))
        rec = {'fixed_fixture': fixed, 'buggy_fixture': buggy, 'actual_observed_verdicts': observed, 'original_flags': {'fixed': env['fixed_test_ran'], 'buggy': env['buggy_test_ran']}, 'failure_name_sets': {'fixed': sorted(env['failed_for_fixed']), 'buggy': sorted(env['failed_for_buggy'])}, 'original_counts': counts, 'original_total': sum(counts.values()), 'typed_label': typed(observed['fixed'], observed['buggy']), 'subprocess_calls': calls}
        assert len(calls) == (1 if buggy == 'COMPILE_SKIP' else 2)
        (case / 'observations.json').write_text(json.dumps(rec, indent=2))
        rows.append(rec)
    complete = [x for x in rows if x['typed_label'] != 'incomplete']
    incomplete = [x for x in rows if x['typed_label'] == 'incomplete']
    assert len(complete) == 4 and len(incomplete) == 16
    nine = [x for x in rows if x['fixed_fixture'] in ['PASS', 'FAIL', 'PROCESS_ERROR'] and x['buggy_fixture'] in ['PASS', 'FAIL', 'PROCESS_ERROR']]
    assert len(nine) == 9 and sorted((x['original_total'] for x in nine if x['typed_label'] == 'incomplete')) == [0, 0, 1, 2, 2]
    exhaustive = []
    states = list(itertools.product(['PASS', 'FAIL', 'MISSING'], repeat=2))
    for n in range(1, 6):
        checked = 0
        for config in itertools.product(states, repeat=n):
            labels = [typed(a, b) for a, b in config]
            assert len(labels) == n and sum(collections.Counter(labels).values()) == n
            assert sum((x == 'incomplete' for x in labels)) == sum(('MISSING' in z for z in config))
            checked += 1
        assert checked == 9 ** n
        exhaustive.append({'assigned_tests': n, 'configurations': checked})
    result = {'started_utc': started, 'finished_utc': utc(), 'elapsed_seconds': time.monotonic() - t, 'source_cell_zero_based': 74, 'source_lines_inclusive': [635, 851], 'cases': rows, 'summary': {'controlled_process_cases': 20, 'actual_process_calls': sum((len(x['subprocess_calls']) for x in rows)), 'complete_pairs': 4, 'incomplete_pairs': 16, 'complete_pairs_correct': all((x['original_total'] == 1 and x['original_counts'][x['typed_label']] == 1 for x in complete)), 'incomplete_pairs_false_behavioral_allocation': sum((x['original_total'] > 0 for x in incomplete)), 'incomplete_pairs_zero_allocations': sum((x['original_total'] == 0 for x in incomplete)), 'typed_partition_configurations': sum((x['configurations'] for x in exhaustive)), 'partition_checks': exhaustive}, 'scope': 'Original retry source unchanged, with only the defects4j executable replaced by a deterministic controlled subprocess adapter. Child exit and output observations are real; their content is synthetic. No original Java project, generated test, model API or historical event rate is executed/estimated.', 'historical_rate_identified': False, 'original_defects4j_run': False}
    (OUT / 'summary.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({'summary_path': str(OUT / 'summary.json'), 'summary': result['summary']}), flush=True)
if __name__ == '__main__':
    main()
