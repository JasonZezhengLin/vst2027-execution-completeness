from pathlib import Path
import ast,itertools,json,runpy,sys
R=Path(__file__).resolve().parent
runpy.run_path(str(R/'code/runner.py'),run_name='__main__')
actual=json.loads((R/'results/caller/summary.json').read_text());expected=json.loads((R/'data/reported_results.json').read_text())
assert actual['summary']==expected['summary']
keys=list(expected['cases'][0]);assert [{k:x[k] for k in keys} for x in actual['cases']]==expected['cases']
class Log:
 def info(self,*args,**kwargs):pass
classifier=runpy.run_path(str(R/'source/typed_state_classifier.py'))['classify'];block=compile(ast.parse((R/'source/accounting_slice.py').read_text()),'accounting_slice.py','exec');rows=[]
counters=['test_passed_on_fixed_but_failed_on_buggy','test_passed_on_buggy_but_failed_on_fixed','test_passed_on_both','test_failed_on_both']
for f,b in itertools.product(['PASS','FAIL','MISSING'],repeat=2):
 env={'fixed_test_ran':f!='MISSING','buggy_test_ran':b!='MISSING','failed_for_fixed':{'test'} if f=='FAIL' else set(),'failed_for_buggy':{'test'} if b=='FAIL' else set(),'logger':Log(),'project_name':'constructed','bug_id':1,'method_signature':'test','new_res':{'passed_uts_num':1},'defects_detected':set()}
 for k in counters+['bug_detected_number','fixed_failed_but_buggy_pass_number','buggy_non_compiled_number']:env[k]=0
 for k in ['bug_detected','fixed_failed_but_buggy_pass','buggy_non_compiled']:env[k]=[]
 exec(block,env);rows.append({'fixed':f,'buggy':b,'original_counts':{k:env[k] for k in counters},'typed_label':classifier(f,b)})
(R/'results/nine_states.json').write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==9 and sum(x['typed_label']=='EXECUTION_INCOMPLETE' for x in rows)==5
print(json.dumps({'result':'PASS','controlled_conditions':20,'real_child_invocations':36,'typed_ledgers':66429,'nine_states':9,'historical_incidence_estimated':False}),flush=True)
