def classify(fixed, buggy):
    if fixed not in {'PASS','FAIL'} or buggy not in {'PASS','FAIL'}:
        return 'EXECUTION_INCOMPLETE'
    return {('PASS','PASS'):'BOTH_PASS',('PASS','FAIL'):'EFFECTIVE',('FAIL','PASS'):'MISGUIDED',('FAIL','FAIL'):'BOTH_FAIL'}[(fixed,buggy)]
