if fixed_test_ran:
    if buggy_test_ran and not failed_for_buggy.issubset(failed_for_fixed):
        logger.info(f"bug detected")
        bug_detected.append((f"{project_name}_{bug_id}", method_signature))
        bug_detected_number += 1
        if f"{project_name}_{bug_id}" not in defects_detected:
            logger.info(f"new defect detected: {project_name}_{bug_id}")
            defects_detected.add(f"{project_name}_{bug_id}")
        if len(failed_for_fixed - failed_for_buggy) > 0:
            test_passed_on_buggy_but_failed_on_fixed += len(failed_for_fixed - failed_for_buggy)
            fixed_failed_but_buggy_pass.append((f"{project_name}_{bug_id}", method_signature))
        if len(failed_for_buggy - failed_for_fixed) > 0:
            test_passed_on_fixed_but_failed_on_buggy += len(failed_for_buggy - failed_for_fixed)

    elif buggy_test_ran and failed_for_buggy.issubset(failed_for_fixed):
        logger.info(f"bug not detected")
        if len(failed_for_fixed - failed_for_buggy) > 0:
            test_passed_on_buggy_but_failed_on_fixed += len(failed_for_fixed - failed_for_buggy)
            fixed_failed_but_buggy_pass.append((f"{project_name}_{bug_id}", method_signature))
            fixed_failed_but_buggy_pass_number += 1
        if len(failed_for_buggy - failed_for_fixed) > 0:
            test_passed_on_fixed_but_failed_on_buggy += len(failed_for_buggy - failed_for_fixed)
    else:
        logger.info("bug detected")
        if f"{project_name}_{bug_id}" not in defects_detected:
            logger.info(f"new defect detected: {project_name}_{bug_id}")
            defects_detected.add(f"{project_name}_{bug_id}")
        bug_detected.append((f"{project_name}_{bug_id}", method_signature))
        bug_detected_number += 1
        buggy_non_compiled_number += 1
        buggy_non_compiled.append((f"{project_name}_{bug_id}", method_signature))
        test_passed_on_fixed_but_failed_on_buggy += (new_res["passed_uts_num"] - len(failed_for_fixed))

else:
    logger.info("Fixed test did not run")
    logger.info("bug not detected")
    if buggy_test_ran:
        fixed_failed_but_buggy_pass.append((f"{project_name}_{bug_id}", method_signature))
        fixed_failed_but_buggy_pass_number += 1
        test_passed_on_buggy_but_failed_on_fixed += (new_res["passed_uts_num"] - len(failed_for_buggy))
test_passed_on_both += new_res["passed_uts_num"] - len(failed_for_fixed.union(failed_for_buggy))
test_failed_on_both += len(failed_for_fixed.intersection(failed_for_buggy))