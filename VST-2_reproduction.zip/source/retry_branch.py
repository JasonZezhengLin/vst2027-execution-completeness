if new_res["passed_uts_num"] != 0:
    defect_with_compilable_test.add(f"{project_name}_{bug_id}")
    fixed_test_ran = True
    failed_for_fixed = set()
    test_command = [
        'defects4j', 'test',
        '-w', project_dir
    ]
    pbar.set_description(f"Running tests of {method_id}")
    logger.info(f"Running tests from {hashed_package_name}: {' '.join(test_command)}")
    try:
        result = subprocess.run(
            test_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=True
        )

        logger.info(result.stdout)
        logger.info(f"Total number of tests generated: {num_tests}")
        logger.info(f"Total number of tests compiled: {new_res['passed_uts_num']}")
        failing_test_match = re.search(r"Failing tests:\s*(\d+)", result.stdout)
        if failing_test_match:
            failing_tests_count = int(failing_test_match.group(1))
            partially_passed.append((f"{project_name}_{bug_id}", method_signature))
            for line in result.stdout.split("\n"):
                if line.strip().startswith('-') and class_name_in_code in line:
                    failed_for_fixed.add(line.strip()[1:].strip())
            logger.info(f"Number of failing tests in LLMGenTest: {len(failed_for_fixed)}")
            if len(failed_for_fixed) > 0:
                logger.info("Fixed LLMGenTest failing in fixed\n  - " + '\n  - '.join(failed_for_fixed))
                test_failed += len(failed_for_fixed)
            else:
                logger.info("Fixed LLMGenTest all passed in fixed")

        else:
            logger.info("No 'Failing tests:' line found in the output. Possibly no failures.")

        if result.returncode == 0:
            logger.info("Tests ran successfully.")
        else:
            logger.error(f"Tests failed with return code: {result.returncode}")

        with open(test_run_log_file_path, 'w') as f:
            f.write(f"Total number of tests generated: {num_tests}\n")
            f.write("-" * 80 + "\n")
            f.write(result.stdout)
            f.write("-" * 80 + "\n")
            f.write(f"Return code: {result.returncode}\n")

    except subprocess.CalledProcessError as e:
        fixed_test_ran = False
        logger.error(f"Error running defects4j test command: {e}")
        compiled_but_run_failed_number += 1
        compiled_but_run_failed.append((f"{project_name}_{bug_id}", method_signature))
        with open(test_run_log_file_path, 'w') as f:
            f.write(e.stdout)
            f.write("-" * 80 + "\n")
            f.write(f"Return code: {e.returncode}\n")
        logger.error(f"error message: \n{e.stdout}")
        logger.error(f"error return code: {e.returncode}")

    finally:
        if os.path.exists(dst_java_file_path):
            logger.info(f"Removing test Java file after testing: {dst_java_file_path}")
            os.remove(dst_java_file_path)
            try:
                os.rmdir(dst_test_package_dir)
                logger.info(f"Removed empty test package directory: {dst_test_package_dir}")
            except OSError:
                pass
    buggy_test_ran = True
    failed_for_buggy = set()
    if new_res['buggy_compiled']:
        # add a separator
        separator_logger.info('-' * 80)
        buggy_test_command = [
            'defects4j', 'test',
            '-w', buggy_project_dir
        ]
        pbar.set_description(f"Running buggy tests of {method_id}")
        logger.info(f"Running buggy tests from {hashed_package_name}: {' '.join(buggy_test_command)}")
        try:
            result = subprocess.run(
                buggy_test_command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                check=True
            )

            logger.info(result.stdout)
            logger.info(f"Total number of tests generated: {num_tests}")
            logger.info(f"Total number of tests compiled: {new_res['passed_uts_num']}")
            failing_test_match = re.search(r"Failing tests:\s*(\d+)", result.stdout)
            if failing_test_match:
                failing_tests_count = int(failing_test_match.group(1))
                for line in result.stdout.split("\n"):
                    if line.strip().startswith('-'):
                        cleaned_line = line.strip()[1:].strip()
                        if class_name_in_code in line:
                            failed_for_buggy.add(line.strip()[1:].strip())
                        else:
                            if len(cleaned_line.split('::')) < 2:
                                logger.warning(f"Error line not in the expected format: {cleaned_line}")
                                continue
                            trig_test_class = cleaned_line.split('::')[0]
                            trig_test_name = cleaned_line.split('::')[1]
                            trig_test_class_dir = trig_test_class.replace('.', os.sep)
                            full_trig_test_path = os.path.join(buggy_test_src_dir, trig_test_class_dir+".java")
                            full_trig_test_path_bak = os.path.join(test_src_dir, trig_test_class_dir+".java.bak")
                            try:
                                with open(full_trig_test_path, 'r', encoding='utf-8', errors='replace') as f:
                                    test_content = f.read()
                            except FileNotFoundError:
                                try: # try to read the backup file
                                    with open(full_trig_test_path_bak, 'r', encoding='utf-8', errors='replace') as f:
                                        test_content = f.read()
                                except FileNotFoundError:
                                    logger.warning(f"Test file not found: {full_trig_test_path} and {full_trig_test_path_bak}")
                                    continue
                            if method_name in check_invocation(parse_classes_from_code(test_content), trig_test_name):
                                focal_method_invoked_defects.add(f"{project_name}_{bug_id}")
                                logger.info(f"Focal method {method_name} invoked in {trig_test_class}::{trig_test_name}")
                                break

                logger.info(f"Number of failing tests in LLMGenTest: {len(failed_for_buggy)}")
                if len(failed_for_buggy) > 0:
                    logger.info("Fixed LLMGenTest failing in buggy\n  - " + '\n  - '.join(failed_for_buggy))
                else:
                    logger.info("Fixed LLMGenTest all passed in buggy")
            else:
                logger.info("No 'Failing tests:' line found in the output. Possibly no failures.")

            if result.returncode == 0:
                logger.info("Tests ran successfully.")
            else:
                item['ran'] = False
                item['run_err_msg'] = result.stdout
                logger.error(f"Tests failed with return code: {result.returncode}")

            with open(buggy_test_run_log_file_path, 'w') as f:
                f.write(f"Total number of tests generated: {num_tests}\n")
                f.write("-" * 80 + "\n")
                f.write(result.stdout)
                f.write("-" * 80 + "\n")
                f.write(f"Return code: {result.returncode}\n")

        except subprocess.CalledProcessError as e:
            buggy_test_ran = False
            logger.error(f"Error running defects4j test command: {e}")
            with open(buggy_test_run_log_file_path, 'w') as f:
                f.write(e.stdout)
                f.write("-" * 80 + "\n")
                f.write(f"Return code: {e.returncode}\n")
            logger.error(f"error message: \n{e.stdout}")
            logger.error(f"error return code: {e.returncode}")
            item['ran'] = False
            item['run_err_msg'] = e.stdout

        finally:
            if os.path.exists(buggy_dst_java_file_path):
                logger.info(f"Removing buggy test Java file after testing: {buggy_dst_java_file_path}")
                os.remove(buggy_dst_java_file_path)
                try:
                    os.rmdir(buggy_dst_test_package_dir)
                    logger.info(f"Removed empty test package directory: {buggy_dst_test_package_dir}")
                except OSError:
                    pass
    else:
        logger.info("Buggy test did not compile")
        buggy_test_ran = False
    # add a separator
    separator_logger.info('-' * 80)
    if fixed_test_ran:
        if buggy_test_ran and not failed_for_buggy.issubset(failed_for_fixed):
            logger.info(f"bug detected")
            bug_detected.append((f"{project_name}_{bug_id}", method_signature))
            bug_detected_number += 1
            if f"{project_name}_{bug_id}" not in defects_detected:
                logger.info(f"new defect detected: {project_name}_{bug_id}")
                defects_detected.add(f"{project_name}_{bug_id}")
            if len(failed_for_fixed - failed_for_buggy) > 0:
                test_passed_on_buggy_but_failed_on_fixed += len(failed_for_fixed - failed_for_buggy)
                fixed_failed_but_buggy_pass.append((f"{project_name}_{bug_id}", method_signature))
            if len(failed_for_buggy - failed_for_fixed) > 0:
                test_passed_on_fixed_but_failed_on_buggy += len(failed_for_buggy - failed_for_fixed)

        elif buggy_test_ran and failed_for_buggy.issubset(failed_for_fixed):
            logger.info(f"bug not detected")
            if len(failed_for_fixed - failed_for_buggy) > 0:
                test_passed_on_buggy_but_failed_on_fixed += len(failed_for_fixed - failed_for_buggy)
                fixed_failed_but_buggy_pass.append((f"{project_name}_{bug_id}", method_signature))
                fixed_failed_but_buggy_pass_number += 1
            if len(failed_for_buggy - failed_for_fixed) > 0:
                test_passed_on_fixed_but_failed_on_buggy += len(failed_for_buggy - failed_for_fixed)
        else:
            logger.info("bug detected")
            if f"{project_name}_{bug_id}" not in defects_detected:
                logger.info(f"new defect detected: {project_name}_{bug_id}")
                defects_detected.add(f"{project_name}_{bug_id}")
            bug_detected.append((f"{project_name}_{bug_id}", method_signature))
            bug_detected_number += 1
            buggy_non_compiled_number += 1
            buggy_non_compiled.append((f"{project_name}_{bug_id}", method_signature))
            test_passed_on_fixed_but_failed_on_buggy += (new_res["passed_uts_num"] - len(failed_for_fixed))

    else:
        logger.info("Fixed test did not run")
        logger.info("bug not detected")
        if buggy_test_ran:
            fixed_failed_but_buggy_pass.append((f"{project_name}_{bug_id}", method_signature))
            fixed_failed_but_buggy_pass_number += 1
            test_passed_on_buggy_but_failed_on_fixed += (new_res["passed_uts_num"] - len(failed_for_buggy))
    test_passed_on_both += new_res["passed_uts_num"] - len(failed_for_fixed.union(failed_for_buggy))
    test_failed_on_both += len(failed_for_fixed.intersection(failed_for_buggy))
